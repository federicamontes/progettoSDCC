import json
import pymongo as pymongo
from random import randrange
import os

def getQuoteByTags(tag):
    
    # connection to MongoAtlas
    client = pymongo.MongoClient(os.environ["MONGODB_ATLAS_CLUSTER_URI"])
    collection = client.test['quotes']
    
    items = list(collection.find({Tags:tag}))
    
    index = 0
    
    if (len(items) == 0):
        return "No quotes!"
    else:
        index = randrange(lenQuotes)
    
    return str(items[index]['Quote']) + " by " + str(items[index]['Author'])



def lambda_handler(event, context):
    # TODO implement
    #tag = event['Category'] #qualcosa in funzione di categoria (da definire)
    
    tag = "sport"
    
    quote = getQuoteByTags(tag)
    
    
    response = {
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {
                "contentType": "SSML",
                "content": "The quote is: {Quote}".format(Quote=quote)
            }
        }
    }
    
    #print('result = ' + str(response))
    return response
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps('Hello from Lambda!')
    # }
