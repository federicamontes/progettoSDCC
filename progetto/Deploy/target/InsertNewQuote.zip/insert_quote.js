
//Parsing Tags values 
function getTagsList(arr) {

    return arr.filter(function(ele){
       return ele.length >4;
    });
  
}

//Parsing values as structed json for MongoDB Atlas schema
function createJSON (input){
    
    var result = input.split(" ");
    var quote = result.slice(0, result.indexOf('by'));
    var author = (result.slice(result.indexOf('by')+1)).join(" ");
    
    return {
        Quote: quote.join(" "),
        Author: author,
        Tags: getTagsList(quote),
        Popularity: Math.random(),
        Category: "other"
    };
    
}


'use strict';
var MongoClient = require('mongodb').MongoClient;


exports.handler = (event, context, callback) => {
    //MongoDB Atlas URI is setted as lambda's env var
    var uri = process.env['MONGODB_ATLAS_CLUSTER_URI'];

    //Creating connection
    const client = new MongoClient(uri, { useNewUrlParser: true });
    client.connect(err => {
        if (err) throw err;
        //Selecting specific db's collection 
        const collection = client.db("test").collection("quotes");
         
        //Processing the input string  
        var newQuoteJSON = createJSON(event.text);
      
        //Executing query
        collection.findOne({Quote:newQuoteJSON.Quote}, function(err, result) {
            if (err) throw err;
            
            if(!result){
                //Adding quote in db if it does not exist
                collection.insertOne(newQuoteJSON, function(err, res) {
                    if (err) throw err;
                    //Sending confirm message to Slack
                    console.log("Your quote has been inserted. Try me c:");
                    context.succeed("Your quote has been inserted. Try me c:");
                
                }); 
            }else{
                //Sending error message to Slack
                console.log("Your quote is already here. Find it ;)")
                context.succeed("Your quote is already here. Find it ;)");
            }
    
        });

        /*test:
        collection.estimatedDocumentCount({}, function(error, numOfDocs){
                if(error) console.log('errore '+error);
                 context.succeed('Number of quotes updated: '+ numOfDocs);
        });*/

    });

};

