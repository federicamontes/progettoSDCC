import pymongo as pymongo
from random import randrange
import os
import json
import boto3


def call_to_Tagslambda(category, author):

    # Init low-level client for SNS connection
    sns = boto3.client('sns')
    
    # Creating json with parameters values
    msg = {"Category": category, "Author":author}

    # Publishing the new SNS topic 
    response = sns.publish(
                    TopicArn=os.environ["SNS_TOPIC_ARN"],
                    Message=json.dumps(msg))
                    
    print("response: " + str(json.dumps(msg)) +  str(response))
    
    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
        return "Loading... :D"
    
    

# always start with the lambda_handler
def getQuote(category, author):
    
    # Connection to MongoDB Atlas
    client = pymongo.MongoClient(os.environ["MONGODB_ATLAS_CLUSTER_URI"])
    collection = client.test['quotes']
    
    # Search quotes just for category by any author
    if author == "any" and category != "any":
        items = list(collection.find({"Category": category}))
    # Search quotes by author or part of an author's name for any category
    elif author != "any" and category == "any":
        items = list(collection.find({"Author": {'$regex': author, '$options': 'i'}}))
    # Search quotes by any author for not formatted categories
    elif author == "any" and category == "any":
        items = list(collection.find({'$or': [{"Category": "quotes"}, {"Category": ""}]}))
    # Search quotes having both category and author
    else:
        items = list(collection.find({"Category": category, "Author": {'$regex': author, '$options': 'i'}}))

    lenQuotes = len(items)
    if lenQuotes == 0:
        return call_to_Tagslambda(category, author)
    if lenQuotes == 1:
        index = 0
    else:
        index = randrange(lenQuotes)
  
    print(str(items[index]['Quote']) + " by " + str(items[index]['Author']))
    return "The quote is: " + str(items[index]['Quote']) + " by " + str(items[index]['Author'])


def lambda_handler(event, context):
    # Parsing data received from Lex trigger
    category = (event['currentIntent']['slots']['Category']).lower()
    author = (event['currentIntent']['slots']['Author']).lower()
   
    # Searching quotes using "Category" and "Author" as keywords 
    quote = getQuote(category, author)

    # Marshalling Lambda message
    response = {
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {
                "contentType": "SSML",
                "content": quote
            }
        }
    }
    

    # Return response to Slack client
    print('result = ' + str(response))
    return response
