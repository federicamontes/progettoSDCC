import pymongo as pymongo
from random import randrange
import os
import json
import requests
import logging

#CludWatch logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def slack_callout(quote):
    try:
        # Creating response json
        response = {"text": quote,
                    "channel": "#%s" % (os.environ['SLACK_CHANNEL'])}

        # Sending response message to Slack webhook
        slack_response = requests.post(os.environ['SLACK_CHANNEL'], json=response,
                                       headers={'Content-Type': 'application/json'})
        return slack_response.status_code
    except:
        return "error"


def getQuoteByTags(tag, author):
    # Connecting to MongoDB Atlas
    client = pymongo.MongoClient(os.environ["MONGODB_ATLAS_CLUSTER_URI"])
    collection = client.test['quotes']

    # Executing query
    if author == "any":
        items = list(collection.find({"Tags": tag}))
    else:
        items = list(collection.find({"Tags": tag, "Author": {'$regex': author, '$options': 'i'}}))

    # Checking query result
    if len(items) == 0:
        return "No quotes! Why don't you try to insert a new one yourself?"
    else:
        index = randrange(len(items))

    return str(items[index]['Quote']) + " by " + str(items[index]['Author'])


def lambda_handler(event, context):
    # Parsing data received from SNS trigger
    msg = event['Records'][0]['Sns']['Message']
    parsed_message = json.loads(msg)

    tag = parsed_message['Category']
    author = parsed_message['Author']

    """
    --Test confirmed subscription--
    client = boto3.client('sns')
    response = client.get_subscription_attributes(
    SubscriptionArn='arn:aws:sns:us-east-1:638927402797:TagForQuote:efd31f0d-6133-456b-a436-4e00cb063340')
    """

    # Searching quotes using "Tags" and "Author" as keywords
    quote = getQuoteByTags(tag, author)

    # Marshalling Slack message
    slack_msg = slack_callout(quote)

    # Returning status_code
    return slack_msg
