import pymongo as pymongo
from random import randrange
import os
import json
from boto3 import client as boto3_client

def getQuoteByTags(tag, author):
    
    # connection to MongoAtlas
    client = pymongo.MongoClient(os.environ["MONGODB_ATLAS_CLUSTER_URI"])
    collection = client.test['quotes']
    
    if author == "any":
        items = list(collection.find({"Tags":tag}))
    else:
        items = list(collection.find({"Tags":tag, "Author": {'$regex': author, '$options': 'i'}}))

    
    print(len(items))
    
    if len(items) == 0:
        return "No quotes!"
    else:
        index = randrange(len(items))
    
    print ( str(items[index]['Quote']) + " by " + str(items[index]['Author']) )
    return str(items[index]['Quote']) + " by " + str(items[index]['Author'])



def lambda_handler(event, context):
    tag = event['Category'] 
    author = event['Author']
    
    quote = getQuoteByTags(tag,author)
    
    return quote
